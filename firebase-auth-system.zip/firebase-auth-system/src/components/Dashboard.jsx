import { auth } from "../firebase/firebaseConfig";
import { signOut } from "firebase/auth";
import { useNavigate } from "react-router-dom";

function Dashboard() {

    const navigate = useNavigate();

    const logoutUser = async () => {
        await signOut(auth);
        navigate("/");
    };

    return (
        <div>
            <h1>Dashboard</h1>

            <p>Welcome {auth.currentUser?.email}</p>

            <button onClick={logoutUser}>
                Logout
            </button>
        </div>
    );
}

export default Dashboard;