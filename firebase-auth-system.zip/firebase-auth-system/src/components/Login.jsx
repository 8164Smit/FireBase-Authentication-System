import { useState } from "react";
import { auth, googleProvider } from "../firebase/firebaseConfig";
import { signInWithEmailAndPassword, signInWithPopup } from "firebase/auth";
import { Link } from "react-router-dom";

import {
    Container,
    Box,
    TextField,
    Button,
    Typography,
    Paper
} from "@mui/material";

function Login() {

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const handleLogin = async (e) => {
        e.preventDefault();

        try {
            await signInWithEmailAndPassword(auth, email, password);
            alert("Login Successful");
        }
        catch (err) {
            alert(err.message);
        }
    };

    const googleLogin = async () => {
        try {
            await signInWithPopup(auth, googleProvider);
        }
        catch (err) {
            alert(err.message);
        }
    };

    return (

        <Container maxWidth="sm">

            <Box
                sx={{
                    height: "100vh",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center"
                }}
            >

                <Paper elevation={6} sx={{ padding: 4, width: "100%" }}>

                    <Typography variant="h4" align="center" gutterBottom>
                        Login
                    </Typography>

                    <Box component="form" onSubmit={handleLogin}>

                        <TextField
                            label="Email"
                            type="email"
                            fullWidth
                            margin="normal"
                            onChange={(e) => setEmail(e.target.value)}
                        />

                        <TextField
                            label="Password"
                            type="password"
                            fullWidth
                            margin="normal"
                            onChange={(e) => setPassword(e.target.value)}
                        />

                        <Button
                            type="submit"
                            variant="contained"
                            fullWidth
                            sx={{ mt: 2 }}
                        >
                            Login
                        </Button>

                        <Button
                            variant="outlined"
                            fullWidth
                            sx={{ mt: 2 }}
                            onClick={googleLogin}
                        >
                            Login with Google
                        </Button>

                        <Typography align="center" sx={{ mt: 2 }}>
                            Don't have an account?{" "}
                            <Link to="/register">Register</Link>
                        </Typography>

                    </Box>

                </Paper>

            </Box>

        </Container>

    );
}

export default Login;