import { useState } from "react";
import { auth } from "../firebase/firebaseConfig";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { Link } from "react-router-dom";

import {
    Container,
    Box,
    TextField,
    Button,
    Typography,
    Paper
} from "@mui/material";

function Register() {

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const handleRegister = async (e) => {
        e.preventDefault();

        try {
            await createUserWithEmailAndPassword(auth, email, password);
            alert("Registration Successful");
        }
        catch (err) {
            alert(err.message);
        }

    };

    return (

        <Container maxWidth="sm">

            <Box
                sx={{
                    height: "100vh",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center"
                }}
            >

                <Paper elevation={6} sx={{ padding: 4, width: "100%" }}>

                    <Typography variant="h4" align="center" gutterBottom>
                        Register
                    </Typography>

                    <Box component="form" onSubmit={handleRegister}>

                        <TextField
                            label="Email"
                            type="email"
                            fullWidth
                            margin="normal"
                            onChange={(e) => setEmail(e.target.value)}
                        />

                        <TextField
                            label="Password"
                            type="password"
                            fullWidth
                            margin="normal"
                            onChange={(e) => setPassword(e.target.value)}
                        />

                        <Button
                            type="submit"
                            variant="contained"
                            fullWidth
                            sx={{ mt: 2 }}
                        >
                            Register
                        </Button>

                        <Typography align="center" sx={{ mt: 2 }}>
                            Already have an account?{" "}
                            <Link to="/">Login</Link>
                        </Typography>

                    </Box>

                </Paper>

            </Box>

        </Container>

    );

}

export default Register;