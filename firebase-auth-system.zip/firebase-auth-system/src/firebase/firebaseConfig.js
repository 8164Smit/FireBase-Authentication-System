import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
    apiKey: "AIzaSyB0kPuZPI-VJKRTChs2JrQot--V9SYIBGM",
    authDomain: "fir-auth-system-ca3cc.firebaseapp.com",
    projectId: "fir-auth-system-ca3cc",
    storageBucket: "fir-auth-system-ca3cc.firebasestorage.app",
    messagingSenderId: "273017744786",
    appId: "1:273017744786:web:c9958c1384e482943a654b",
    databaseURL: "https://fir-auth-system-ca3cc-default-rtdb.firebaseio.com/"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const database = getDatabase(app);
export const googleProvider = new GoogleAuthProvider();